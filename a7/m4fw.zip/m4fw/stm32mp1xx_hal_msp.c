#include "stm32mp1xx_hal.h"
#include "mbox_ipcc.h"

/*
 * UART7: PE8 = TX (AF8), PE7 = RX (AF8)
 * DE/RE: PE0 = RS-485 direction control (Arduino D4)
 */

void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef g = {0};

    if (huart->Instance == UART7) {
        __HAL_RCC_GPIOE_CLK_ENABLE();
        __HAL_RCC_UART7_CLK_ENABLE();

        /* PE8 — UART7_TX */
        g.Pin       = GPIO_PIN_8;
        g.Mode      = GPIO_MODE_AF_PP;
        g.Pull      = GPIO_NOPULL;
        g.Speed     = GPIO_SPEED_FREQ_MEDIUM;
        g.Alternate = 8U;  /* AF8 = UART7 on PE7/PE8 */
        HAL_GPIO_Init(GPIOE, &g);

        /* PE7 — UART7_RX */
        g.Pin       = GPIO_PIN_7;
        g.Mode      = GPIO_MODE_AF_PP;
        g.Pull      = GPIO_PULLUP;
        g.Alternate = 8U;  /* AF8 = UART7 on PE7/PE8 */
        HAL_GPIO_Init(GPIOE, &g);

        /* PE0 — RS-485 DE (output, start LOW = RX mode) */
        g.Pin       = GPIO_PIN_0;
        g.Mode      = GPIO_MODE_OUTPUT_PP;
        g.Pull      = GPIO_NOPULL;
        g.Speed     = GPIO_SPEED_FREQ_MEDIUM;
        g.Alternate = 0;
        HAL_GPIO_Init(GPIOE, &g);
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_RESET);

        /* UART7 interrupt */
        HAL_NVIC_SetPriority(UART7_IRQn, 5, 0);
        HAL_NVIC_EnableIRQ(UART7_IRQn);
    }
}

/* ── IPCC (needed by OpenAMP mailbox) ──────────────────────────────── */
void HAL_IPCC_MspInit(IPCC_HandleTypeDef *hipcc)
{
    (void)hipcc;
    __HAL_RCC_IPCC_CLK_ENABLE();
    HAL_NVIC_SetPriority(IPCC_RX1_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(IPCC_RX1_IRQn);
}

void HAL_IPCC_MspDeInit(IPCC_HandleTypeDef *hipcc)
{
    (void)hipcc;
    HAL_NVIC_DisableIRQ(IPCC_RX1_IRQn);
}

/* ── UART7 ──────────────────────────────────────────────────────────── */
void HAL_UART_MspDeInit(UART_HandleTypeDef *huart)
{
    if (huart->Instance == UART7) {
        __HAL_RCC_UART7_FORCE_RESET();
        __HAL_RCC_UART7_RELEASE_RESET();
        HAL_GPIO_DeInit(GPIOE, GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_0);
        HAL_NVIC_DisableIRQ(UART7_IRQn);
    }
}
