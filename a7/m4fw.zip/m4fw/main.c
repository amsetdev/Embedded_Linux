/*
 * STM32MP157F-DK2  Cortex-M4 firmware
 * Bridges UART7 (PE8=TX, PE7=RX, PE0=DE) <-> RPMsg "rpmsg-tty" endpoint.
 * A7 Linux sees /dev/ttyRPMSG0 via the rpmsg_tty kernel driver.
 *
 * Flow: M4 calls OPENAMP_create_endpoint("rpmsg-tty") to ANNOUNCE the endpoint.
 *       Linux rpmsg_tty driver detects it and creates /dev/ttyRPMSG0.
 */

#include "main.h"
#include "openamp.h"
#include "rsc_table.h"
#include "stm32mp1xx_hal.h"

/* ── UART7 ─────────────────────────────────────────────────────────── */
#define UART7_BAUD       9600U
#define RS485_DE_PORT    GPIOE
#define RS485_DE_PIN     GPIO_PIN_0
#define RING_SIZE        256U

UART_HandleTypeDef huart7;

static uint8_t  uart_rx_byte;
static uint8_t  uart_rx_buf[RING_SIZE];
static volatile uint32_t uart_rx_head = 0;
static volatile uint32_t uart_rx_tail = 0;
static volatile int uart_tx_busy = 0;

/* ── RPMsg ──────────────────────────────────────────────────────────── */
static struct rpmsg_endpoint uart_ept;

static int rpmsg_recv_cb(struct rpmsg_endpoint *ept, void *data,
                         size_t len, uint32_t src, void *priv);

/* ── UART7 helpers ──────────────────────────────────────────────────── */
static void uart7_init(void)
{
    huart7.Instance          = UART7;
    huart7.Init.BaudRate     = UART7_BAUD;
    huart7.Init.WordLength   = UART_WORDLENGTH_8B;
    huart7.Init.StopBits     = UART_STOPBITS_1;
    huart7.Init.Parity       = UART_PARITY_NONE;
    huart7.Init.Mode         = UART_MODE_TX_RX;
    huart7.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart7.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart7);
    HAL_UART_Receive_IT(&huart7, &uart_rx_byte, 1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *h)
{
    if (h->Instance == UART7) {
        uint32_t next = (uart_rx_head + 1) % RING_SIZE;
        if (next != uart_rx_tail) {
            uart_rx_buf[uart_rx_head] = uart_rx_byte;
            uart_rx_head = next;
        }
        HAL_UART_Receive_IT(&huart7, &uart_rx_byte, 1);
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *h)
{
    if (h->Instance == UART7) {
        HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_RESET);
        uart_tx_busy = 0;
    }
}

static void uart7_send(const uint8_t *buf, uint32_t len)
{
    HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_SET);
    uart_tx_busy = 1;
    HAL_UART_Transmit_IT(&huart7, (uint8_t *)buf, len);
}

static void flush_uart_to_rpmsg(void)
{
    uint8_t tmp[64];
    uint32_t n = 0;

    while (uart_rx_tail != uart_rx_head && n < sizeof(tmp)) {
        tmp[n++] = uart_rx_buf[uart_rx_tail];
        uart_rx_tail = (uart_rx_tail + 1) % RING_SIZE;
    }
    if (n > 0 && is_rpmsg_ept_ready(&uart_ept))
        rpmsg_send(&uart_ept, tmp, n);
}

static int rpmsg_recv_cb(struct rpmsg_endpoint *ept, void *data,
                         size_t len, uint32_t src, void *priv)
{
    (void)ept; (void)src; (void)priv;
    if (len == 0 || uart_tx_busy)
        return 0;
    uart7_send((const uint8_t *)data, (uint32_t)len);
    return 0;
}

/* ── main ───────────────────────────────────────────────────────────── */
int main(void)
{
    HAL_Init();

    /* IPCC must be initialized before MX_OPENAMP_Init/MAILBOX_Init.
     * hipcc is defined in platform.c; mbox_ipcc.c externs it.
     * Without this, MAILBOX_Init silently fails and all IPCC
     * notifications (virtqueue kicks) go to address 0 — Linux never
     * receives any rpmsg messages. */
    extern IPCC_HandleTypeDef hipcc;
    hipcc.Instance = IPCC;
    if (HAL_IPCC_Init(&hipcc) != HAL_OK)
        while (1);

    /* Initialize OpenAMP — M4 is REMOTE, no ns_bind_cb */
    MX_OPENAMP_Init(RPMSG_REMOTE, NULL);

    /* Announce "rpmsg-tty" endpoint — Linux rpmsg_tty driver will detect
     * this and create /dev/ttyRPMSG0 automatically */
    OPENAMP_create_endpoint(&uart_ept, "rpmsg-tty", RPMSG_ADDR_ANY,
                            rpmsg_recv_cb, NULL);

    /* Wait for Linux to connect to the endpoint */
    OPENAMP_Wait_EndPointready(&uart_ept);

    /* Endpoint is connected — now start UART7 */
    uart7_init();

    for (;;) {
        OPENAMP_check_for_message();
        flush_uart_to_rpmsg();
    }
}

/* ── UART7 IRQ ──────────────────────────────────────────────────────── */
void UART7_IRQHandler(void)
{
    HAL_UART_IRQHandler(&huart7);
}
